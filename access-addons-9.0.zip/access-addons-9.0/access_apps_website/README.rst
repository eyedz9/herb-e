Restrict access to "Install Apps" in Website
=============================================

Shows "Install Apps" item in the "Customize" menu in Website only for users with "Show Apps Menu" access.

Tested on 9.0 2ec9a9c99294761e56382bdcd766e90b8bc1bb38
