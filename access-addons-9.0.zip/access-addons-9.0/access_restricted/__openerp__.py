{
    'name': 'Restricted administration rights',
    'version': '1.1.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'category': 'Tools',
    'website': 'https://twitter.com/yelizariev',
    'price': 30.00,
    'currency': 'EUR',
    'depends': ['ir_rule_protected'],
    'data': [
        'security.xml',
    ],
    'installable': True
}
