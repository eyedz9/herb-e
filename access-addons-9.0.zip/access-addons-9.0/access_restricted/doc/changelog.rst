Changelog
=========

`1.1.0`
-------

- ADD: Make restricted groups readonly in Settigs pages (res.config.settings)
- ADD: don't restrict access to Technical Settings group

`1.0.1`
-------

- FIX: update to the latest odoo 9.0 version due to this comit from Mar 24, 2016 https://github.com/odoo/odoo/commit/40a299c580c4608edab8781fda4e66f39611543b

`1.0.0`
-------

- init version
