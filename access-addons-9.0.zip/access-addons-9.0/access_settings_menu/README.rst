Show settings menu for non-admin
================================

Adds "Show Settings Menu" tick in user's access rights tab.

Tested on 9.0 2ec9a9c99294761e56382bdcd766e90b8bc1bb38
