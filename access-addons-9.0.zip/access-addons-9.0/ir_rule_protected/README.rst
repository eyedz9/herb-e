Protect ir.rule records
=======================

The module allows protect ir.rule from modifying and deleting. Once a rule is marked as protected only superuser is able to control this rule.

Also, the module protect itself from uninstalling by non-superuser.

Tested on 9.0 2ec9a9c99294761e56382bdcd766e90b8bc1bb38
