{
    'name': 'Protect ir.rule records',
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'category': 'Tools',
    'website': 'https://twitter.com/yelizariev',
    'depends': [],
    'data': [
        'views.xml',
    ],
    'installable': True
}
