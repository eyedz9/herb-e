===============================================
 Start-End dates in invoice and analytic lines
===============================================

Usage
=====

* Grant access to ``Analytic Accounting`` and ``Financial Manager``

  * Open ``Settings/Users/Users`` - choose your user
  * click edit
  * set ``Technical settings`` checkbox
  * choose ``Financial Manager`` in ``Accounting & Finance`` selection
  * click save
  * press F5
  * click edit
  * set ``Analytic Accounting`` checkbox
  * click save
  * press F

* Create new invoice with Start Date, End date, Analytic Account
* Validate
* Open ``Invoicing/Jounal Entries/Analytic Journal Items``
  * new Items have Start, End Dates
