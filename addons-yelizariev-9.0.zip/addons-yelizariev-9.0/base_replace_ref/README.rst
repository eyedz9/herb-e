Replace x2y references
======================

The module allows to create rules to execute replacement for relation field.

Tested on Odoo 8.0 bf9544d7d430704efd006cca182a7120a55a0c8a
