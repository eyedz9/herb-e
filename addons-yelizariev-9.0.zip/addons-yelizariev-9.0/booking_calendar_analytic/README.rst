Booking Calendar Analytic
=========================

With this module you can group booking lines by contract. Additional button "Booking List"
will appear in Contract form, when you install this module.


Tested on Odoo 8.0 e84c01ebc1ef4fdf99865c45f10d7b6b4c4de229
