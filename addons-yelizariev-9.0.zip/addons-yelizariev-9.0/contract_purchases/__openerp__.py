{
    'name' : 'Purchases in contract',
    'version' : '1.0.0',
    'author' : 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category' : 'Sales',
    'website' : 'https://yelizariev.github.io',
    'description': """

    """,
    'depends' : ['account_analytic_analysis', 'purchase'],
    'data':[
        'data.xml',
        'views.xml',
        ],
    'installable': False,
}
