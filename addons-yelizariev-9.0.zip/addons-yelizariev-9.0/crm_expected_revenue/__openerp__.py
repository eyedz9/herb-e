{
    'name': "Multiply  expected revenue by probability",
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Custom',
    'website': 'https://yelizariev.github.io',
    'depends': ['crm'],
    'data': [
        'views.xml',
        ],
    'installable': False
}
