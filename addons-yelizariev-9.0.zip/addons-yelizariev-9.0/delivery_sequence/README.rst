Delivery Sequence
=================

Module adds Sequence field to Delivery Methods for sorting.

Tested on Odoo 8.0 f8d5a6727d3e8d428d9bef93da7ba6b11f344284
