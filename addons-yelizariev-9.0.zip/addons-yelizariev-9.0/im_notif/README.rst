IM Notifications
================

Description: https://apps.odoo.com/apps/modules/8.0/im_notif/

Further information and discussion: https://yelizariev.github.io/odoo/module/2015/02/18/im-notifications.html

Tested on Odoo 8.0 ab7b5d7732a7c222a0aea45bd173742acd47242d
