.. _changelog:

Changelog
=========

`1.0.1`
-------

- Hide Notifications user
