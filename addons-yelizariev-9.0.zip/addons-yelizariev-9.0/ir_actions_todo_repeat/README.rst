Ir Action Todo Repeat
================================================================

The module adds the ability to create repeating wizards. Repetition will occur until the record parameter "repeat" 
in the model "ir.actions.todo" is True.


Tested on Odoo 9.0 2ec9a9c99294761e56382bdcd766e90b8bc1bb38
