{
    'name': "Force move attachments to DB storage",
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Tools',
    'website': 'https://yelizariev.github.io',
    'depends': [],
    'data': [
        'data.xml'
        ],
    'installable': True
}
