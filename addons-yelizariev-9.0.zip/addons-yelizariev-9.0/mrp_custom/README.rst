Custom models for MRP
