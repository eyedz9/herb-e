Fix gaps in Repair order numbering
==================================

https://github.com/odoo/odoo/issues/4258

Tested on Odoo 8.0 ea60fed97af1c139e4647890bf8f68224ea1665b
