{
    'name': "Fix gaps in Repair order numbering",
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Custom',
    'website': 'https://yelizariev.github.io',
    'depends': ['mrp_repair'],
    'data': [
        'views.xml',
        ],
    'installable': False
}
