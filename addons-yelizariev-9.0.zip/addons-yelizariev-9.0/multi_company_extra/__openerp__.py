{
    "name" : "Updates for multi company mode",
    "version" : "0.1",
    "author" : "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    "category" : "Tools",
    "website" : "https://yelizariev.github.io",
    "description": """


    """,
    "depends" : ['account_voucher', 'sale_stock'],
    "data":[
        'views.xml'
        ],
    'installable': False
}
