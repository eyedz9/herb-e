{
    'name' : 'Product\'s fields (custom)',
    'version' : '1.0.0',
    'author' : 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category' : 'Custom',
    'website' : 'https://yelizariev.github.io',
    'description': """

Tested on Odoo 8.0 935141582f5245f7cf5512285d3d91dfe58cb570
    """,
    'depends' : ['product'],
    'data':[
        'views.xml',
        ],
    'installable': False
}
