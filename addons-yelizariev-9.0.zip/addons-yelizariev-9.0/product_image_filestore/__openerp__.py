{
    'name' : 'Store product images in filestore',
    'version' : '1.0.0',
    'author' : 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category' : 'Custom',
    'website' : 'https://yelizariev.github.io',
    'summary': 'Check WARNING before installing \ uninstalling!',
    'depends' : ['product'],
    'data':[],
    'installable': False
}
