Product price without taxes
===========================

The module add column "Price Unit (without taxes)" to sale order and invoice, because out-of-box odoo shows included-in-price taxes in "Price Unit" field.

In invoice and quotatine reports the module replace "Price Unit" to "Price Unit (without taxes)".

Check images/ folder for screenshots

Tested on Odoo 8.0 258a4cac82ef3b7e6a086f691f3bf8140d37b51c
