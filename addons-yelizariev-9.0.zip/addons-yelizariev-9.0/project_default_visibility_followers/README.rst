"Private project: followers Only" as default value
==================================================
When creating the project, the value of Privacy / Visibility will be
set to 'Private project: followers Only'
