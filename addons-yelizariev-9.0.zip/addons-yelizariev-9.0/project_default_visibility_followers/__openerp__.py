# -*- coding: utf-8 -*-
{
    'name': "Private project: followers Only",
    'author': "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    'website': "https://yelizariev.github.io",
    'category': 'Project',
    'version': '1.0.0',
    'depends': ['project'],
    'installable': False,
    'auto_install': False,
}
