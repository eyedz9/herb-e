Changelog
=========

`1.1.0`
-------

- ADD: add filter Name to search by Name only

`1.0.0`
-------

- init version
