Reminders and Agenda (technical core)
=====================================

Description: https://apps.odoo.com/apps/modules/8.0/reminder_base

Tested on Odoo 8.0 ea4f9c4625ec8eebcf337bbd8a8b44d68c377ad7

Known issues
------------

* Mail notification doesn't work without email_from parameter in odoo configuration file due to odoo bug, that was fixed 11th Feb 2015 in this commit: https://github.com/odoo/odoo/commit/064f18e6b6003b7fcb3aa5f5072e8e00d18acbb0 . 
