.. _changelog:

Changelog
=========

`1.0.4`
-------

- Fix: don't send mail to attendees after record creation or after date changing

`1.0.3`
-------

- Fix: check that partner record exists before add one to attendees

`1.0.2`
-------

- Fix unnecessary updating of calendar event

`1.0.1`
-------

- Fix: check for duplicates in attendees fields
