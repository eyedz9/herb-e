Reminders and Agenda for Job Applications
=========================================

Description: https://apps.odoo.com/apps/modules/8.0/reminder_hr_recruitment/

Tested on Odoo 8.0 a0797d3b35cc235048e7947dd7a3d38e18c3e350
