Reminders and Agenda for phonecalls
===================================

Description: https://apps.odoo.com/apps/modules/8.0/reminder_phonecall/

Tested on Odoo 8.0 ea4f9c4625ec8eebcf337bbd8a8b44d68c377ad7
