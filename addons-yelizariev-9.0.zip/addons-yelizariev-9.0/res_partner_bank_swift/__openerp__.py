{
    "name" : "SWIFT for res.partner.bank",
    "version" : "1.0.0",
    "author" : "IT-Projects LLC, Ivan Yelizariev",
    'license': 'LGPL-3',
    "category" : "Sales Management",
    "website" : "https://yelizariev.github.io",
    "description": """
    """,
    "depends" : ['base'],
    "data":[
        'views.xml'
        ],
    'installable': False
}
