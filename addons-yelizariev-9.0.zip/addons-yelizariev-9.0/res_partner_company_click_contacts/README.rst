Full view for company's contacts
================================

By default, odoo open company's contacts in popup with a simplified
form. This module redefine this behaviour to open company's contacts
with full form.

Tested on Odoo 8.0 ea60fed97af1c139e4647890bf8f68224ea1665b
