Aggregate messages from company's contacts
==========================================

By default, odoo displays under partner form only its own messages. The module shows under company form both their own messages and the messages of any contacts attached to that company. 

Tested on Odoo 8.0 ea60fed97af1c139e4647890bf8f68224ea1665b
