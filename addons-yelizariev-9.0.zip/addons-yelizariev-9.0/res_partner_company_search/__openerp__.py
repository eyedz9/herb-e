{
    'name' : 'Search partner by company fields',
    'version' : '1.0.0',
    'author' : 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category' : 'Tools',
    'website' : 'https://yelizariev.github.io',
    'depends' : ['base'],
    'data':[
        'views.xml',
        ],
    'installable': False
}
