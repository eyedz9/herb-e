Auto-fill partner's country by top-lever domain of email address
================================================================

The module:

* auto-fill country field for a new partner
* adds country field to short partner form

Known issues
------------

* raise unknown error from "Search more" button in country dropdown list (see https://github.com/odoo/odoo/pull/8483 )

Tested on Odoo 8.0 c345d294b12f3ac3e3c8b549e0633686d017d0fe
