# -*- coding: utf-8 -*-
{
    'name': "phone and mobile in display_name for searching",
    'author': "IT-Projects LLC, Ildar Nasyrov",
    'website': "https://twitter.com/nasyrov_ildar",
    'category': 'Uncategorized',
    'version': '1.0.0',
    'depends': ['base'],
    'data': [

    ],
    "installable": True
}
