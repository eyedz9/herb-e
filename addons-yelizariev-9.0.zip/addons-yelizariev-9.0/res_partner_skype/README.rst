Skype field in partner form
===========================

Description: https://www.odoo.com/apps/modules/8.0/res_partner_skype

Adds skype field to partner form. When you click on skype address, chat window is opened.

Further information and discussion: http://yelizariev.github.io/odoo/module/2015/03/31/skype.html
