Trim partner's name
===================

Delete spaces and quotes around partner name. Can be usefull if partner is created from incoming email.
