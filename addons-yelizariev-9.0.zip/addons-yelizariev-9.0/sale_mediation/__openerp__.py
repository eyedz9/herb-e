{
    'name' : 'Sales in mediation company ',
    'version' : '1.0.0',
    'author' : 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category' : 'Workflow',
    'website' : 'https://yelizariev.github.io',
    'description': """

    """,
    'depends' : ['sale', 'crm', 'project', 'contract_purchases'],
    'data':[
        'views.xml',
        #'data.xml',
        ],
    'installable': False,
}
