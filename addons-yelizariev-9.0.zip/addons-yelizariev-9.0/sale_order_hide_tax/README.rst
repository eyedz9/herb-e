Sale Order with tax information hidden
======================================

Description: Hides tax information from Sale Order view.

Tested on Odoo 8.0 e84c01ebc1ef4fdf99865c45f10d7b6b4c4de229
