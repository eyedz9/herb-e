# -*- coding: utf-8 -*-
{
    'name': "Sale order with tax information hidden",
    'author': "IT-Projects LLC, Ildar Nasyrov",
    'license': 'LGPL-3',
    'website': "https://twitter.com/nasyrov_ildar",
    'category': 'Uncategorized',
    'version': '1.0.0',
    'depends': ['base', 'sale'],
    'data': [
        'security/security.xml',
        'views/view.xml',
    ],
}
