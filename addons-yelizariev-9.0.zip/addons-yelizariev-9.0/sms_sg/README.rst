sms.sg service's bridge
=======================

Description: Sends sms through sms.sg service HTTP API. Logs sent sms.

Tested on Odoo 8.0 e84c01ebc1ef4fdf99865c45f10d7b6b4c4de229
