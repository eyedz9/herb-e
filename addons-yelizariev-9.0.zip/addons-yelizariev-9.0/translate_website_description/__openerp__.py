{
    'name' : 'Translate website_description',
    'version' : '1.0.0',
    'author' : 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category' : 'Tools',
    'website' : 'https://yelizariev.github.io',
    'description': """

    """,
    'depends' : ['website_partner','website_sale_delivery', 'website_sale', 'website_quote'],
    'data':[],
    'installable': False
}
