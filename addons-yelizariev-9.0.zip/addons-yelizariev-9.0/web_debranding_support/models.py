# -*- coding: utf-8 -*- 
from openerp import api, models, fields, SUPERUSER_ID
