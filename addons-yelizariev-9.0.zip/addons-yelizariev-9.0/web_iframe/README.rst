IFrame pages
============

The module allows create menus with iframe content

Tested on Odoo 8.0 935141582f5245f7cf5512285d3d91dfe58cb570
