IFrame pages
============

The module creates top menu "IFrame" where you can put submenu with iframes.

Note, that after any editing you have to refresh page.

Tested on Odoo 8.0 d023c079ed86468436f25da613bf486a4a17d625
