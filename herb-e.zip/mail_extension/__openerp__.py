# -*- coding: utf-8 -*-

{
    'name': 'Mail Extension',
    'version': '1.0',
    'author': 'Grover Menacho',
    'category': 'General',
    'sequence': 27,
    'summary': '',
    'website': 'http://grovermenacho.com',
    'description': """Custom base mail for messages
    """,
    'images': [],
    'depends': ['mail'],
    'data': [
    ],
    'qweb': [],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
}
