Odoo POS addons
===============

Odoo (OpenERP) POS addons 

List of repositories:
---------------------

* https://github.com/yelizariev/addons-yelizariev
* https://github.com/yelizariev/pos-addons
* https://github.com/yelizariev/mail-addons
* https://github.com/yelizariev/rental-addons
* https://github.com/yelizariev/access-addons
* https://github.com/yelizariev/website-addons
* https://github.com/yelizariev/l10n-addons
* https://github.com/yelizariev/odoo-saas-tools
