{
    'name': "Custom Sale Details report",
    'version': '1.0.0',
    'author': 'IT-Projects LLC, Ivan Yelizariev',
    'license': 'LGPL-3',
    'category': 'Custom',
    'website': 'https://yelizariev.github.io',
    'depends': ['point_of_sale'],
    'data': [
        'views.xml',
        ],
    'installable': False,
}
