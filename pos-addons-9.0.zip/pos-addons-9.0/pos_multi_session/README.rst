Sync POS orders across multiple sessions
========================================

Tested on Odoo 9.0 4f7d0da94204dc6685c87cbfc675a7c38039aee5
