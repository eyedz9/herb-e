.. _changelog:

Changelog
=========

`1.0.4`
-------
- FIX: Print only not printed order lines (*Order* button).

`1.0.3`
-------
- IMP: For pos restaurant compatibility. Sync notes. Sync guests.

`1.0.2`
-------
- FIX: For pos restaurant compatibility. Sync printed positions.

`1.0.1`
-------

- Fix.Orders some times was out of sync. Now its ok.
- Fix a bug related to updates in built-in bus module from Jan 20th 2016: https://github.com/odoo/odoo/commit/8af3841cb25cee33fd503ebe692abb8f98d4840a
- Added demo data.
- New: keep empty order. In previous version we deleted it when new Order from another POS is come. Now you can set it up in settings.
- New: switch on income order if active order is empty. You can chose to switch on new income order or not.


`1.0.0`
-------

- init version
