Available quantity of products in POS
=====================================

Description: https://apps.odoo.com/apps/modules/8.0/pos_product_available/
