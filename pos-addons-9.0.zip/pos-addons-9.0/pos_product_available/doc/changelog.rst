.. _changelog:

Changelog
=========

`1.0.3`
-------

- [FIX] compatibility with pos_cache module. Thanks to MindAndGo.

`1.0.2`
-------

- [FIX] update product counter when sale via invoice

`1.0.1`
-------

- Show quantity related to POS's stock location only.
