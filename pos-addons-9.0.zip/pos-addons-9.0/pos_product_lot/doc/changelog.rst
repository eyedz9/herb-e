.. _changelog:

Changelog
=========

`1.0.1`
-------

- [FIX] spliting lot was lost if one click button quick enough
- [IMP] support multi-stock configuration
