Sale orders in POS
==================

Fill pos cart by sale order ID.

Tested on Odoo 8.0 d023c079ed86468436f25da613bf486a4a17d625
