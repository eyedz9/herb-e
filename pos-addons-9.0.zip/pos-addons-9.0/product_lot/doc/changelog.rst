.. _changelog:

Changelog
=========

`1.0.1`
-------

- [IMP] support multi-stock configuration
