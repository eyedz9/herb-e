=====================
Debt notebook for POS
=====================

Comfortable sales for your regular customers.

The module allows makes sales on credit in a single click. You do not need to take money from
a customer each time. You'll be able to offer your customer to make prepayment or pay periodically,
e.g. once in a month. It's a good solution for small shops with regular customers.

Also, the customer is able to pay some part by cash and the rest by debt.

Usage
=====

Credits
=======

Contributors
------------
* krotov@it-projects.info

Sponsors
--------
* `IT-Projects LLC <https://it-projects.info>`_

Further information
===================

HTML Description: https://apps.odoo.com/apps/modules/9.0/tg_pos_debt_notebook/

Tested on Odoo 9.0 9cdc40e3edf2e497c4660c7bb8d544f750b3ef60
