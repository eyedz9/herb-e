.. _changelog:

Changelog
=========

`1.0.3`
-------

- Improve button.set-customer-pay-full-debt on PoS customer list

`1.0.2`
-------

- Add button "pay full debt" to make it easier for the user to manage the scenario where a customer comes to pay his debt

`1.0.1`
-------

- Add French translation
- Minor code syntax enhancements
